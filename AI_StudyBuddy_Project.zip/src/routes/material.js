const router = require("express").Router();
const Material = require("../models/Material");
const auth = require("../middleware/auth");

router.post("/upload", auth, async (req, res) => {
  try {
    const { title, content } = req.body;
    if (!title || !content) return res.status(400).json({ message: "Title and content are required" });

    const material = await Material.create({ title, content, user: req.user.id });
    res.status(201).json(material);
  } catch (err) {
    res.status(500).json({ message: "Material upload failed", error: err.message });
  }
});

router.post("/:id/summarize", auth, async (req, res) => {
  try {
    const material = await Material.findOne({ _id: req.params.id, user: req.user.id });
    if (!material) return res.status(404).json({ message: "Material not found" });

    const summary = material.content.length > 500
      ? material.content.slice(0, 500) + "..."
      : material.content;

    res.json({ materialId: material._id, summary });
  } catch (err) {
    res.status(500).json({ message: "Summary failed", error: err.message });
  }
});

module.exports = router;
