const router = require("express").Router();
const auth = require("../middleware/auth");

router.post("/flashcards", auth, (req, res) => {
  const { topic } = req.body;
  res.json({
    topic: topic || "General",
    flashcards: [
      { question: "What is the main idea of this topic?", answer: "Review the supplied study material." },
      { question: "What should you remember first?", answer: "Focus on the key definitions and concepts." }
    ]
  });
});

router.post("/quiz", auth, (req, res) => {
  const topic = req.body.topic || "General";
  res.json({
    topic,
    quiz: [
      { question: `Which statement best describes ${topic}?`, options: ["Key concept A", "Key concept B", "Key concept C", "Key concept D"] }
    ]
  });
});

router.post("/study-plan", auth, (req, res) => {
  const topic = req.body.topic || "General";
  res.json({
    topic,
    plan: [
      "Day 1: Learn the basic concepts",
      "Day 2: Review examples",
      "Day 3: Practice questions",
      "Day 4: Revise weak areas",
      "Day 5: Take a self-test"
    ]
  });
});

module.exports = router;
